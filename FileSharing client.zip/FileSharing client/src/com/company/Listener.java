package com.company;

/**
 * Created by hackeru on 3/30/2017.
 */
public interface Listener {
     void printSautes(long percent);
}

