package com.company;


public interface Key {
    int key();
}
