package com.company;

/**
 * Created by This_user on 26/03/2017.
 */
public interface Output {
    void output(String s);
}
