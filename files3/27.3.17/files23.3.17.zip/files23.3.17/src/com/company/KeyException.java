package com.company;

/**
 * Created by hackeru on 3/21/2017.
 */
public class KeyException extends Exception {
}
