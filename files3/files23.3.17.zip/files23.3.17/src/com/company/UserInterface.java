package com.company;

/**
 * Created by hackeru on 3/19/2017.
 */
public interface UserInterface {
      void output(String s);
      String input();
}
