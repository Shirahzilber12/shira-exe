package com.company;

/**
 * Created by hackeru on 3/28/2017.
 */
public class Users {
    String userName;
    String password;
}
