package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Created by hackeru on 3/14/2017.
 */
class MenuTest {
    @Test
    void start() {
        String s = "s";
        Menu.menu(s);
    }

    @Test
    void menu() {

    }

    @Test
    void start2() {

    }

    @Test
    void getFile() {

    }

}