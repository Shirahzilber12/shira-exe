package com.company;

/**
 * Created by hackeru on 3/14/2017.
 */
public class WrapTest {
    public WrapTest() {}
    Menu menu = new Menu();

}
