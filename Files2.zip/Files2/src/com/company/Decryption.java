package com.company;

//פענוח
public class Decryption implements Operation {
    public static void decryption(){
        System.out.println("the file is decryption");
    }
}
