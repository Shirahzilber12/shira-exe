package com.company;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

//הצפנה
public class Encryption implements Operation {

    public static void encryptionCaesar(){
        Random random = new Random(System.currentTimeMillis());
        int num = random.nextInt();
        File file = new File("C:\\Users\\hackeru.HACKERU3\\Documents\\GitHub\\shira-exe\\encryption.txt");
        OutputStream outputStream = null;
        InputStream inputStream = null;
        byte[] buffer = new byte[4];
        while (buffer = inputStream.read()!=)

    }

}
