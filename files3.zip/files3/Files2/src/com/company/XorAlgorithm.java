package com.company;

import java.io.File;

/**
 * Created by This_user on 19/03/2017.
 */
public class XorAlgorithm implements Algorithm,Key {
    @Override
    public void typeOfKey() {

    }

    @Override
    public void decryption(File file, int key) {

    }

    @Override
    public void encryption(File file, int key) {

    }
}
