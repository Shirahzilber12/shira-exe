package com.company;

/**
 * Created by This_user on 19/03/2017.
 */
public interface Key {
    void typeOfKey();
}
